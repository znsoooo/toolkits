import idlealib
idlealib.run()
